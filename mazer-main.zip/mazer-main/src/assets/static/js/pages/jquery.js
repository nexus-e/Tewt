let $ = require("jquery")
